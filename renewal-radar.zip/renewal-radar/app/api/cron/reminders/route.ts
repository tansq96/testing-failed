import { advance, daysUntil, isoDate, money, todayUTC, type Subscription } from "@/lib/billing";
import { supabaseAdmin } from "@/lib/supabase/server";

type Row = Subscription & { user_id: string; last_reminded: string | null };

// Runs once a day (see vercel.json). Emails reminders and rolls past charge dates forward.
export async function GET(request: Request) {
  if (request.headers.get("authorization") !== `Bearer ${process.env.CRON_SECRET}`) {
    return new Response("Unauthorized", { status: 401 });
  }

  const db = supabaseAdmin();
  const today = todayUTC();
  const horizon = isoDate(new Date(today.getTime() + 3 * 86_400_000));
  const { data, error } = await db.from("subscriptions").select("*").lte("next_charge", horizon);
  if (error) return new Response(error.message, { status: 500 });

  const due = new Map<string, Row[]>();
  for (const s of (data ?? []) as Row[]) {
    const days = daysUntil(s.next_charge, today);

    // Paid subscriptions renew: move a past date to the next cycle.
    if (days < 0 && !s.is_trial) {
      let next = s.next_charge;
      while (daysUntil(next, today) < 0) next = advance(next, s.cycle);
      await db.from("subscriptions").update({ next_charge: next }).eq("id", s.id);
      continue;
    }

    const remind = s.is_trial ? days === 3 || days === 1 : days === 1;
    if (remind && s.last_reminded !== isoDate(today)) {
      due.set(s.user_id, [...(due.get(s.user_id) ?? []), s]);
    }
  }

  let sent = 0;
  for (const [userId, subs] of due) {
    const { data: profile } = await db.from("profiles").select("email").eq("id", userId).single();
    if (!profile?.email) continue;
    if (await sendEmail(profile.email, subs, today)) {
      sent++;
      await db.from("subscriptions").update({ last_reminded: isoDate(today) }).in("id", subs.map((s) => s.id));
    }
  }
  return Response.json({ checked: data?.length ?? 0, emailed: sent });
}

async function sendEmail(to: string, subs: Row[], today: Date): Promise<boolean> {
  const lines = subs.map((s) => {
    const days = daysUntil(s.next_charge, today);
    const label = days === 1 ? "tomorrow" : `in ${days} days`;
    return s.is_trial
      ? `• ${s.name}: free trial ends ${label}, then ${money(Number(s.price), s.currency)}/${s.cycle}`
      : `• ${s.name}: ${money(Number(s.price), s.currency)} charges ${label}`;
  });
  const subject = subs.length === 1
    ? `${subs[0].name} ${subs[0].is_trial ? "trial is ending soon" : "charges tomorrow"}`
    : `${subs.length} subscriptions are about to charge you`;
  const text = `${lines.join("\n")}\n\nNeed to cancel? Do it now so you aren't charged.\n\n${process.env.NEXT_PUBLIC_SITE_URL ?? ""}`;

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: process.env.EMAIL_FROM, to, subject, text }),
  });
  return res.ok;
}
