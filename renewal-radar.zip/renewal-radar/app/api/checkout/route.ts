import { NextResponse } from "next/server";
import Stripe from "stripe";
import { supabaseAdmin, supabaseServer } from "@/lib/supabase/server";

// Sends the signed-in visitor to Stripe's hosted checkout for the Pro plan.
export async function POST(request: Request) {
  const origin = new URL(request.url).origin;
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect(new URL("/login", origin), 303);

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
  const admin = supabaseAdmin();
  const { data: profile } = await admin.from("profiles").select("stripe_customer_id").eq("id", user.id).single();

  let customer = profile?.stripe_customer_id as string | null;
  if (!customer) {
    customer = (await stripe.customers.create({ email: user.email, metadata: { user_id: user.id } })).id;
    await admin.from("profiles").update({ stripe_customer_id: customer }).eq("id", user.id);
  }

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer,
    line_items: [{ price: process.env.STRIPE_PRICE_ID!, quantity: 1 }],
    success_url: `${origin}/?upgraded=1`,
    cancel_url: `${origin}/`,
    allow_promotion_codes: true,
  });
  return NextResponse.redirect(session.url!, 303);
}
