import Stripe from "stripe";
import { supabaseAdmin } from "@/lib/supabase/server";

// Stripe calls this when a Pro subscription starts, changes or ends.
export async function POST(request: Request) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      await request.text(),
      request.headers.get("stripe-signature") ?? "",
      process.env.STRIPE_WEBHOOK_SECRET!,
    );
  } catch {
    return new Response("Invalid signature", { status: 400 });
  }

  if (event.type.startsWith("customer.subscription.")) {
    const sub = event.data.object as Stripe.Subscription;
    const active = ["active", "trialing", "past_due"].includes(sub.status);
    await supabaseAdmin()
      .from("profiles")
      .update({ plan: active ? "pro" : "free" })
      .eq("stripe_customer_id", sub.customer as string);
  }
  return new Response("ok");
}
