"use client";

import { useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";

export default function Login() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");

  async function send(e: React.FormEvent) {
    e.preventDefault();
    setState("sending");
    const { error } = await supabaseBrowser().auth.signInWithOtp({
      email,
      options: { emailRedirectTo: `${window.location.origin}/auth/callback` },
    });
    setState(error ? "error" : "sent");
  }

  if (state === "sent") {
    return (
      <section className="hero">
        <h1>Check your email</h1>
        <p>We sent a sign-in link to {email}. Open it on this device to continue.</p>
      </section>
    );
  }

  return (
    <section className="hero">
      <h1>Sign in</h1>
      <p>Enter your email and we&apos;ll send you a sign-in link. No password needed.</p>
      <form className="card" onSubmit={send}>
        <label>Email<input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <button className="btn" type="submit" disabled={state === "sending"}>
          {state === "sending" ? "Sending…" : "Email me a link"}
        </button>
        {state === "error" && <p className="note">That didn&apos;t send. Check the address and try again.</p>}
      </form>
    </section>
  );
}
