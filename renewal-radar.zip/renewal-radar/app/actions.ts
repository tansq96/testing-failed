"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { FREE_LIMIT } from "@/lib/billing";
import { supabaseServer } from "@/lib/supabase/server";

export async function addSubscription(form: FormData) {
  const supabase = await supabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const [{ data: profile }, { count }] = await Promise.all([
    supabase.from("profiles").select("plan").eq("id", user.id).single(),
    supabase.from("subscriptions").select("id", { count: "exact", head: true }),
  ]);
  if (profile?.plan !== "pro" && (count ?? 0) >= FREE_LIMIT) redirect("/?limit=1");

  const cycle = String(form.get("cycle"));
  await supabase.from("subscriptions").insert({
    user_id: user.id,
    name: String(form.get("name") ?? "").trim().slice(0, 80),
    price: Number(form.get("price")) || 0,
    currency: String(form.get("currency") ?? "USD"),
    cycle: ["week", "month", "year"].includes(cycle) ? cycle : "month",
    next_charge: String(form.get("next_charge")),
    is_trial: form.get("is_trial") === "on",
  });
  revalidatePath("/");
}

export async function removeSubscription(form: FormData) {
  const supabase = await supabaseServer();
  await supabase.from("subscriptions").delete().eq("id", String(form.get("id")));
  revalidatePath("/");
}

export async function signOut() {
  const supabase = await supabaseServer();
  await supabase.auth.signOut();
  redirect("/");
}
