export type Cycle = "week" | "month" | "year";

export type Subscription = {
  id: string;
  name: string;
  price: number;
  currency: string;
  cycle: Cycle;
  next_charge: string;
  is_trial: boolean;
};

export const FREE_LIMIT = 5;

const DAY = 86_400_000;

export function todayUTC(): Date {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
}

export function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export function daysUntil(date: string, from = todayUTC()): number {
  return Math.round((new Date(date + "T00:00:00Z").getTime() - from.getTime()) / DAY);
}

export function perMonth(s: Pick<Subscription, "price" | "cycle">): number {
  const price = Number(s.price);
  if (s.cycle === "year") return price / 12;
  if (s.cycle === "week") return (price * 52) / 12;
  return price;
}

// Moves a charge date forward by one billing cycle.
export function advance(date: string, cycle: Cycle): string {
  const d = new Date(date + "T00:00:00Z");
  if (cycle === "week") d.setUTCDate(d.getUTCDate() + 7);
  if (cycle === "month") d.setUTCMonth(d.getUTCMonth() + 1);
  if (cycle === "year") d.setUTCFullYear(d.getUTCFullYear() + 1);
  return isoDate(d);
}

export function money(amount: number, currency = "USD"): string {
  try {
    return new Intl.NumberFormat("en", { style: "currency", currency }).format(amount);
  } catch {
    return `${currency} ${amount.toFixed(2)}`;
  }
}

export function when(days: number): string {
  if (days < 0) return "overdue";
  if (days === 0) return "today";
  if (days === 1) return "tomorrow";
  return `in ${days} days`;
}
